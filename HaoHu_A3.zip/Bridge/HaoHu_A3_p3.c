#include <stdio.h>
#include <stdlib.h>
//#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include <semaphore.h>
#include "Queue.h"

sem_t bridge;
int cars_c = 0;
int direction=-1;
int pre_dirct=-1;
int n = 0; // number of cars
pthread_mutex_t lock;
int current_time = 1;
int cross_time = 5;
Queue_t* q;

void ArriveBridge(){
    sem_wait(&bridge);
}

void ExitBridge(){
    sem_post(&bridge);
}

void CrossBridge(char* driver, int flag){
    if(flag)printf("Direction:%s\n", (direction==0)?"North":"South");
    printf("%s\n", driver);
    pthread_mutex_lock(&lock);
    cars_c += 1;
    pthread_mutex_unlock(&lock);
    sleep(cross_time);//cross the bridge
    pthread_mutex_lock(&lock);
    cars_c -= 1;
    if(cars_c==0){pre_dirct=direction;direction=-1;}
    pthread_mutex_unlock(&lock);
}

void* CarT(void* args){
     Car_t car = *(Car_t*)args;
     free(args);
     int direc = ((strcmp(car.direction,"N")==0)?0:1);
     while(1){
         ArriveBridge();//up the sem
         if(direction==-1){
             direction = direc;
             CrossBridge(car.driver, (pre_dirct==direc)?0:1);
             ExitBridge();//down the sem
             break;
         } else {
             if(direction==direc){
                  CrossBridge(car.driver, 0);
             } else {
                  continue;
             }
             ExitBridge();//down the sem
             break;
         }
     }
}

void get_input_data() {
    //The first line of input is ignored as the header
    int r;
    char* t1 = (char*)malloc(255);
    char* t2 = (char*)malloc(255);
    char* t3 = (char*)malloc(255);
    r = scanf("%s\t%s\t%s", t1, t2, t3);
    free(t1);
    free(t2);
    free(t3);
    if (r<0) {
        printf("input format is not correct.\n");
        exit(0);
    }

    //read the rest of the data
    while (1) {
        char* driver = (char*)malloc(255);
        char* direction = (char*)malloc(255);
        int arrival;
        int r = scanf("%s\t%s\t%d", driver, direction, &arrival);
        if (r<0) {
            free(driver);
            free(direction);
            break;
        }
        else {
            Car_t car;
            car.driver = driver;
            car.direction = direction;
            car.arrival = arrival;
            enqueue(q, car);
            n += 1;
        }
    }
    queue_sort(q);//sort the q according to arriving time
}

int main(int argc, char** argv) {
    if(argc<2){
        printf("please give car crossing time.\n");
        printf("example command: %s 5", argv[0]);
        exit(0);
    }
    cross_time = atoi(argv[1]);
    if(cross_time<=0){
        printf("incorrect crossing time.\n");
        printf("example command: %s 5", argv[0]);
        exit(0);
    }
    q = (Queue_t*)malloc(sizeof(Queue_t));
    initialize(q);
    get_input_data();
    if(n==0){
        printf("incorrect input data");
        exit(0);
    }
    int i=0;
    sem_init(&bridge, 0, 3);
    pthread_mutex_init(&lock, NULL);
    pthread_t* cars = (pthread_t*)malloc(sizeof(pthread_t)*n);
    int empty = 0;
    while(1){
        while(1){
            Car_t car = peep(q);
            if(car.arrival == current_time){
                dequeue(q);
                Car_t* tmp = (Car_t*)malloc(sizeof(Car_t));
                memcpy(tmp, &car, sizeof(Car_t));
                pthread_create(&cars[i], NULL, CarT, (void*)tmp);
                i+=1;
                if(q->head==NULL){
                    empty=1;
                    break;
                }
            } else {
                break;
            }
        }
        if(empty)break;
        sleep(1);
        current_time+=1;
    }

    for(i=0;i<n;i++){
        pthread_join(cars[i], NULL);
    }

    pthread_mutex_destroy(&lock);
    free(cars);
    free(q);
    return 0;
}

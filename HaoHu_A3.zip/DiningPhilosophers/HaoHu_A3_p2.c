#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <string.h>
#include <semaphore.h>

#define CHECK(id) (state[id]==1 && state[(id-1+n)%n]!=2 && state[(id+1)%n]!=2)
#define LEFT(id) ((id-1+n)%n)
#define RIGHT(id) ((id+1)%n)

int min = 1;
int max = 2;

int n = 5; //total number of philosophers

//sem_t* phi;
pthread_cond_t* cond_var;
int* state; //0 thinking, 1 hungry, 2 eating
pthread_mutex_t lock; //access lock

void init_locks(){
	pthread_mutex_init(&lock, NULL);
	int i;
	for (i = 0; i < n; ++i)
	{
		pthread_cond_init(&cond_var[i],NULL);
	}
}

void destroy_locks(){
	pthread_mutex_destroy(&lock);
	int i;
	for (i = 0; i < n; ++i)
	{
		pthread_cond_destroy(&cond_var[i]);
	}
}

float get_random_time() { //get random numbers in [min,max]
	float r = ((float)rand()/(float)RAND_MAX)*(max-min) + (float)min;
	return r;
}

void pickup_forks(int id){
	pthread_mutex_lock(&lock);
	state[id]=1; //hungry
	while(!CHECK(id)){
		printf("philosopher %d is waiting.\n", id);
		pthread_cond_wait(&cond_var[id], &lock);
	}
	state[id]=2;//eating
	printf("philosopher %d is eating.\n", id);
	pthread_mutex_unlock(&lock);
}

void return_forks(int id){
	int left = LEFT(id);
	int right = RIGHT(id);
	state[id]=0; //thinking
	printf("philosopher %d return forks.\n", id);
	if(CHECK(left))
	{
		pthread_mutex_lock(&lock);
		pthread_cond_signal(&cond_var[left]);
		pthread_mutex_unlock(&lock);
	}
	if(CHECK(right)){
		pthread_mutex_lock(&lock);
		pthread_cond_signal(&cond_var[right]);
		pthread_mutex_unlock(&lock);
	}
}

void* philosophers(void* args) {
    int id = *(int*)args;
    while(1) {
    	printf("philosopher %d is thinking.\n", id);
    	sleep(get_random_time()); //thinking
    	printf("philosopher %d is hungry.\n", id);
    	pickup_forks(id);
    	sleep(get_random_time()); //eating
    	return_forks(id);
    }
}


int main(int argc, char** argv)
{
  	//random seed
  	srand(time(NULL));

	int i;

	cond_var = (pthread_cond_t*)malloc(sizeof(pthread_cond_t)*n);
	state = (int*)malloc(sizeof(int)*n);

	init_locks();

	//create philosopher threads.
	pthread_t* philosopher_t = (pthread_t*)malloc(sizeof(pthread_t)*n);
	for(i=0; i<n; i++) {
		int *args = (int*)malloc(sizeof(int));
        *args=i;
		pthread_create(&philosopher_t[i], NULL, philosophers, args);
	}

	for(i=0; i<n; i++){
        pthread_join(philosopher_t[i], NULL);
    }

    destroy_locks();

    free(cond_var);
    free(state);
    free(philosopher_t);

	return(0);
}

#include <stdio.h>
#include <stdlib.h>

typedef struct Node
{
	int value;
	struct Node* next;
} Node_t;

typedef struct List {
	Node_t* head;
	Node_t* tail;
} List_t;

void list_initialize(List_t* l) {
	l->head = NULL;
	l->tail = NULL;
}

void add(List_t* l, int v) {
	Node_t* tmp_node = (Node_t*)malloc(sizeof(Node_t));
	tmp_node->value = v;
	tmp_node->next = NULL;
	if (!l->head) {
		l->head = tmp_node;
		l->tail = tmp_node;
	} else {
		if (l->head == l->tail) {
			if (l->head->value <= v) {
				l->head->next = tmp_node;
				l->tail = tmp_node;
			}
			else {
				tmp_node->next = l->head;
				l->head = tmp_node;
			}
			return;
		}
		Node_t* p = l->head;
		while (p!=l->tail) {
			if (p->value <= v) {
				if (p->next->value > v) {
					tmp_node->next = p->next;
					p->next = tmp_node;
					return;
				}
				else {
					p = p->next;
				}
			} else {
				l->head = tmp_node;
				tmp_node->next = p;
				return;
			}
		}
		if (p == l->tail) {
			p->next = tmp_node;
			l->tail = tmp_node;
		}
	}
}

void remove_first(List_t* l) {
	if (!l->head) {
		printf("null list");
		return;
	} else {
		if (l->head == l->tail) {
			Node_t* tmp_node = l->head;
			l->head = NULL;
			l->tail = NULL;
			free(tmp_node);
		}
		else {
			Node_t* tmp_node = l->head;
			l->head = l->head->next;
			free(tmp_node);
		}
	}
}

void list_print(List_t* l) {
	Node_t* tmp_node = l->head;
	while(tmp_node)
	{
		printf("%d ", tmp_node->value);
		tmp_node = tmp_node->next;
	}
}


//int main()
//{
//	char* line;
//	char* end;
//	FILE *f;
//	char buff[255];
//	fopen_s(&f, "data_list", "r");
//
//	List_t* l = (List_t*)malloc(sizeof(List_t));
//	list_initialize(l);
//
//	while (fgets(buff, sizeof(buff), f)) {
//		for (line = buff; ; line = end) {
//			int v = strtol(line, &end, 10);
//			if (line == end) { break; }
//			add(l, v);
//		}
//	}
//
//	fclose(f);
//
//	list_print(l);
//
//	for (int i = 0; i <= 98; i++)
//	{
//		remove_first(l);
//	}
//
//	printf("\r\n");
//	list_print(l);
//
//	return(0);
//}

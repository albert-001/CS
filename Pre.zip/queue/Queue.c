#include <stdio.h>
#include <stdlib.h>

typedef struct Node
{
	int value;
	struct Node* next;
} Node_t;

typedef struct Queue {
	Node_t* head;
	Node_t* tail;
} Queue_t;

void initialize(Queue_t* q) {
	q->head = NULL;
	q->tail = NULL;
}

void enqueue(Queue_t* q, int v) {
	Node_t* tmp_node = (Node_t*)malloc(sizeof(Node_t));
	tmp_node->value = v;
	tmp_node->next = NULL;
	if (!q->head) {
		q->head = tmp_node;
		q->tail = tmp_node;
	}
	else {
		q->tail->next = tmp_node;
		q->tail = tmp_node;
	}
}

void dequeue(Queue_t* q) {
	if (!q->head) {
		return;
	}
	else {
		if (q->head == q->tail) {
			Node_t* tmp_node = q->head;
			q->head = NULL;
			q->tail = NULL;
			free(tmp_node);
		}
		else {
			Node_t* tmp_node = q->head;
			q->head = q->head->next;
			free(tmp_node);
		}
	}
}

void queue_print(Queue_t* q) {
	Node_t* tmp_node = q->head;
	while (tmp_node)
	{
		printf("%d ", tmp_node->value);
		tmp_node = tmp_node->next;
	}
}
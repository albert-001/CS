#ifndef Queue_FILE
#define Queue_FILE

#include <stdio.h>
#include <stdlib.h>
#include "Node.h"


typedef struct Queue {
	QNode_t* head;
	QNode_t* tail;
} Queue_t;

void initialize(Queue_t* q) {
	q->head = NULL;
	q->tail = NULL;
}

Job_t peep(Queue_t* q) {
	if (q->head) {
		return q->head->job;
	}
}

void enqueue(Queue_t* q, Job_t job) {
	QNode_t* tmp_node = (QNode_t*)malloc(sizeof(QNode_t));
	tmp_node->job.user = job.user;
	tmp_node->job.process = job.process;
	tmp_node->job.arrival = job.arrival;
	tmp_node->job.duration = job.duration;
	tmp_node->job.priority = job.priority;
	tmp_node->next = NULL;
	if (!q->head) {
		q->head = tmp_node;
		q->tail = tmp_node;
	}
	else {
		q->tail->next = tmp_node;
		q->tail = tmp_node;
	}
}

Job_t dequeue(Queue_t* q) {
	if (!q->head) {
		return;
	}
	else {
		if (q->head == q->tail) {
			QNode_t* tmp_node = q->head;
			q->head = NULL;
			q->tail = NULL;
			Job_t r = tmp_node->job;
			free(tmp_node);
			return r;
		}
		else {
			QNode_t* tmp_node = q->head;
			q->head = q->head->next;
			Job_t r = tmp_node->job;
			free(tmp_node);
			return r;
		}
	}
}

void queue_print(Queue_t* q) {
	QNode_t* tmp_node = q->head;
	while (tmp_node)
	{
		printf("%s\t", tmp_node->job.user);
		printf("%s\t", tmp_node->job.process);
		printf("%d\t", tmp_node->job.arrival);
		printf("%d\t", tmp_node->job.duration);
		printf("%d\n", tmp_node->job.priority);
		tmp_node = tmp_node->next;
	}
	printf("\n");
}

void queue_sort(Queue_t* q) {
    QNode_t* h1;
    QNode_t* h2;
    QNode_t* h3;
    QNode_t* h = (QNode_t*)malloc(sizeof(QNode_t));
    h->next = q->head;
    for(h3=h->next,h2=h3->next;h2!=NULL;) {
        for(h1=h;h1!=h2;h1=h1->next) {
            if(h1->next->job.arrival > h2->job.arrival) {
               h3->next=h2->next;
               h2->next=h1->next;
               h1->next=h2;
               h2=h3->next;
               break;
            }
        }
 
        if(h1==h2) {
            h2=h2->next;
            h3=h3->next;
        }
    }
    q->head = h->next;
    q->tail = h3;
    free(h);
}


#endif

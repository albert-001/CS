#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <string.h>
#include "Queue.h"
#include "List.h"

Queue_t* q; // the waiting queue
List_t* l; // the running queue
int q_size = 0; //numebr of jobs in total
int current_time = 1; //current time
int dequeued_count = 0;
int processed_count = 0;
Summary_t* sums;
int user_count = 0;
char** users;
int cpu_no = 1;
int n = 1;
pthread_mutex_t list_lock;
pthread_mutex_t cpu_lock;

int sync_incr_cpu_no(){
	pthread_mutex_lock(&cpu_lock);
	int this_cpu_no = cpu_no;
	cpu_no += 1;
	pthread_mutex_unlock(&cpu_lock);
	return this_cpu_no;
}

void sync_add_list(List_t* l, Job_t job){
	pthread_mutex_lock(&list_lock);
	add(l, job);
	pthread_mutex_unlock(&list_lock);
}

void get_input_data() { //read all the jobs into the waiting queue
	//The first line of input is ignored as the header
	int r;
	char* t1 = (char*)malloc(255);
	char* t2 = (char*)malloc(255);
	char* t3 = (char*)malloc(255);
	char* t4 = (char*)malloc(255);
	char* t5 = (char*)malloc(255);
	r = scanf("%s\t%s\t%s\t%s\t%s", t1, t2, t3, t4, t5);
	free(t1);
	free(t2);
	free(t3);
	free(t4);
	free(t5);
	if (r<0) {
		printf("input format is not correct.\n");
		exit(0);
	}

	//read the rest of the data
	while (1) {
		char* user = (char*)malloc(255);
		char* process = (char*)malloc(255);
		int arrival;
		int duration;
		int priority;
		int r = scanf("%s\t%s\t%d\t%d\t%d", user, process, &arrival, &duration, &priority);
		if (r<0) {
			free(user);
			free(process);
			break;
		}
		else {
			Job_t job;
			job.user = user;
			job.process = process;
			job.arrival = arrival;
			job.duration = duration;
			job.priority = priority;
			enqueue(q, job);
			q_size += 1;
		}
	}
	queue_sort(q);//sort the q according to arriving time
	QNode_t* h;
	for(h=q->head; h!=NULL; h=h->next){
		int user_exists = 0;
		int j;
		for (j = 0; j < user_count; j++) {
			if (strcmp(h->job.user, users[j]) == 0) {
				user_exists = 1;
				break;
			}
		}
		if(user_exists==0){
			users[user_count] = h->job.user;
			user_count += 1;
		}
	}
}

//CPU working thread
void* worker(void* args) {
	Job_t cpu_job;
  	int this_cpu_no = sync_incr_cpu_no();

	while(1) {
		pthread_mutex_lock(&list_lock);
		if (l->head) { //jobs in the running queue
			cpu_job = remove_first(l); //get a job from the list
			printf("%d\t%s\n", current_time, cpu_job.process);
			pthread_mutex_unlock(&list_lock);

			//update sums table.
			int j;
			for (j = 0; j<user_count; j++) {
				if (strcmp(cpu_job.user, sums[j].user) == 0) {
					sums[j].end = current_time + cpu_job.duration;
					break;
				}
			}

			//process the job
			sleep(1);
			cpu_job.duration -= 1;
			if (cpu_job.duration > 0) {
				sync_add_list(l, cpu_job); //move the job back to the waiting list
			} else {
				processed_count += 1; //the job is finished
			}
		} else { //nothing to process now
			pthread_mutex_unlock(&list_lock);
			if (n == 1) {
				printf("%d\tIDLE\n", current_time);
			}
			else {
				printf("%d\tCPU %d IDLE\n", current_time, this_cpu_no);
			}
			sleep(1);
		}
		if (processed_count == q_size) {
			if (n == 1) {
				printf("%d\tIDLE\n", current_time);
			}
			else {
				printf("%d\tCPU %d IDLE\n", current_time, this_cpu_no);
			}
			break; //all work are done. leave now.
		}
	}
}

void init_locks(){
	pthread_mutex_init(&list_lock, NULL);
	pthread_mutex_init(&cpu_lock, NULL);	
}

void destroy_locks(){
	pthread_mutex_destroy(&list_lock);
	pthread_mutex_destroy(&cpu_lock);
}


int main(int argc, char** argv)
{
	if (argc < 2) {
		printf("please give a CPU number.\n");
		exit(0);
	}

	n = atoi(argv[1]);
	if (n == 0) {
		printf("please give a valid CPU number.\n");
		exit(0);
	}

	int i;
	q = (Queue_t*)malloc(sizeof(Queue_t)); // the waiting queue
	l = (List_t*)malloc(sizeof(List_t)); // the running queue

	initialize(q);
	list_initialize(l);

	init_locks();

	users = (char**)malloc(sizeof(char*)*255);
	for (i = 0; i < 255; i++) {
		users[i] = (char*)malloc(255);
	}
	get_input_data();

	sums = (Summary_t*)malloc(sizeof(Summary_t)*q_size);
	for (i = 0; i < user_count; i++) {//init sums
		sums[i].user = users[i];
		sums[i].end = 0;
	}

	//create n workers.
	pthread_t* threads = (pthread_t*)malloc(sizeof(pthread_t)*n);
	for(i=0; i<n; i++) {
		pthread_create(&threads[i], NULL, worker, NULL);
	}

	printf("Time\tJob\n");

	//mimic operating system's event loop
	while (1)
	{
		//if new arriving jobs can be added to the list
		while (dequeued_count < q_size) { //if new jobs are waiting
			Job_t tmp_job = peep(q);
			if (tmp_job.arrival == current_time) {
			  	tmp_job = dequeue(q);
				dequeued_count += 1;
				sync_add_list(l, tmp_job);
			}
			else {
				break;
			}
		}

		if(processed_count == q_size) {
			break;
		}

		sleep(1);
		current_time += 1;

		if(processed_count == q_size) {
			break;
		}
	}

	for(i=0; i<n; i++) {
		pthread_join(threads[i], NULL);
	}

	//print summary finally
	printf("\nSummary\n");
	for (i = 0; i < user_count; i++) {
		printf("%s\t%d\n", sums[i].user, sums[i].end);
	}

	free(sums);
	free(q);
	free(l);
	for (i = 0; i < q_size; i++) {
		free(users[i]);
	}
	free(users);

	destroy_locks();

	return(0);
}


/*
The following is a test case to test the priority queue (List_t).
/*
/*
int main() {
		List_t* l = (List_t*)malloc(sizeof(List_t));
		list_initialize(l);
		int i;
		for (i = 10; i > 0; i--) {
		Job_t job;
		job.user = (char*)malloc(255);
		job.process = (char*)malloc(255);
		strcpy((char*)job.user, "A");
		strcpy((char*)job.process, "A");
		job.arrival = i;
		job.duration = i;
		job.priority = 1;
		add(l, job);
		}
		list_print(l);
		for (i = 10; i > 1; i--) {
		remove_first(l);
		}
		list_print(l);
}
*/

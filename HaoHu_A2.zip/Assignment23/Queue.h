#ifndef Queue_FILE
#define Queue_FILE

#include <stdio.h>
#include <stdlib.h>
#include "Node.h"


typedef struct Queue {
	QNode_t* head;
	QNode_t* tail;
} Queue_t;

void initialize(Queue_t* q) {
	q->head = NULL;
	q->tail = NULL;
}

void enqueue(Queue_t* q, int v) {
	QNode_t* tmp_node = (QNode_t*)malloc(sizeof(QNode_t));
	tmp_node->value = v;
	tmp_node->next = NULL;
	if (!q->head) {
		q->head = tmp_node;
		q->tail = tmp_node;
	}
	else {
		q->tail->next = tmp_node;
		q->tail = tmp_node;
	}
}

int dequeue(Queue_t* q) {
	if (!q->head) {
		return -1;
	}
	else {
		if (q->head == q->tail) {
			QNode_t* tmp_node = q->head;
			q->head = NULL;
			q->tail = NULL;
			int r = tmp_node->value;
			free(tmp_node);
			return r;
		}
		else {
			QNode_t* tmp_node = q->head;
			q->head = q->head->next;
			int r = tmp_node->value;
			free(tmp_node);
			return r;
		}
	}
}

void queue_print(Queue_t* q) {
	QNode_t* tmp_node = q->head;
	while (tmp_node)
	{
		printf("%d ", tmp_node->value);
		tmp_node = tmp_node->next;
	}
}

int queue_size(Queue_t* q) {
	int i = 0;
	QNode_t* tmp_node = q->head;
	while (tmp_node)
	{
		i++;
		tmp_node = tmp_node->next;
	}
	return i;
}

#endif

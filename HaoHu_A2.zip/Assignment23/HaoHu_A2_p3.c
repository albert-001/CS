#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <string.h>
#include "Queue.h"


int n = 3; //total number of student
int current_time = 0;
int stop = 100; //time to stop the simulation.
int min = 4;  //min random number
int max = 5;  //max random number
int stu_no = 1;  //student id
int ta_sleeping = 1;
Queue_t* q; //a queue with 3 chairs
pthread_mutex_t cpu_lock;
pthread_mutex_t ta_lock; //TA working lock
pthread_mutex_t q_lock; //queue access lock
//a set of students working lock
pthread_mutex_t* stu_lock;
int* stu_waiting;

void init_locks(){
	pthread_mutex_init(&cpu_lock, NULL);
	pthread_mutex_init(&ta_lock, NULL);
	pthread_mutex_init(&q_lock, NULL);
	int i;
	for(i=0; i<n; i++){
		pthread_mutex_init(&stu_lock[i], NULL);
	}
}

void destroy_locks(){
	pthread_mutex_destroy(&cpu_lock);
	pthread_mutex_destroy(&ta_lock);
	pthread_mutex_destroy(&q_lock);
	int i;
	for(i=0; i<n; i++){
		pthread_mutex_destroy(&stu_lock[i]);
	}
}

//get stu no
int sync_incr_stu_no(){
	pthread_mutex_lock(&cpu_lock);
	int this_stu_no = stu_no;
	stu_no += 1;
	pthread_mutex_unlock(&cpu_lock);
	return this_stu_no;
}

//wake TA up
void sync_wake_ta_up(int stu_id){
	pthread_mutex_lock(&ta_lock);
	if(ta_sleeping){
		printf("Student %d wakes up TA.\n", stu_id);
		ta_sleeping = 0;
	}
	pthread_mutex_unlock(&ta_lock);
}

float get_random_time() { //get random numbers in [min,max]
	float r = ((float)rand()/(float)RAND_MAX)*(max-min) + (float)min;
	return r;
}

//student
void* stu(void* args) {
    int id = sync_incr_stu_no();
	while(current_time<stop){
		pthread_mutex_lock(&q_lock);//update queue
		//then seek for help
		int q_size = queue_size(q);
		//if chairs are empty, check if ta is sleeping, wake him up
		if(q_size==0){
			enqueue(q, id);
			pthread_mutex_unlock(&q_lock);

			sync_wake_ta_up(id);//wake up TA
			//wait for TA to start
			while(stu_waiting[id]){
				if(current_time<stop){
					sleep(0.1);
			  } else {
					break;
				}
			};

			sleep(1);//wait for CA to get the lock first
			pthread_mutex_lock(&stu_lock[id]);//wait for TA to release the lock to continue
			pthread_mutex_unlock(&stu_lock[id]);
			stu_waiting[id] = 1;
		}else if(q_size<3){ //else if there is vacancy in one of the chairs, wait there
			enqueue(q, id);
			pthread_mutex_unlock(&q_lock);

			//wait for TA to start
			printf("Student %d is waiting.\n", id);
			while(stu_waiting[id]){
				if(current_time<stop){
					sleep(0.1);
			  } else {
					break;
				}
			};

			sleep(1);//wait for CA to get lock
			pthread_mutex_lock(&stu_lock[id]);//wait for TA to release the lock to continue
			pthread_mutex_unlock(&stu_lock[id]);
			stu_waiting[id] = 1;
		}else{ //else go back to do programming in mad
			pthread_mutex_unlock(&q_lock);
			printf("Student %d left mad.\n", id);
		}
		//programming for a random period of time
		float programming_time = get_random_time();
		sleep(programming_time);
	}
	//printf("Student%d stops.\n", id);
}

//TA
void* ta(void* args) {
	printf("The TA is napping.\n");
	int current_stu = 0;
	while(current_time<stop){
		//TA sleep
		while(ta_sleeping){
			if(current_time<stop){
				sleep(0.1);
			} else {
				break;
			}
		};

		//if any student waiting in the chairs, call him in
		int q_size = queue_size(q);
		if(q_size>0){
			current_stu = dequeue(q);
			stu_waiting[current_stu] = 0;

			pthread_mutex_lock(&stu_lock[current_stu]);
			float help_time = get_random_time();
			printf("Student %d is getting help for %f seconds.\n", current_stu, help_time);
			sleep(help_time); //help some time
			pthread_mutex_unlock(&stu_lock[current_stu]);//release the lock and let student go back to program
		}else{
				ta_sleeping = 1;
				printf("The TA is napping.\n");
		}
	}
	printf("TA stops.\n");
}

/*
Input
my_prog –n 3 –stop 100 –min 4 –max 5
*/
void get_parameters(int argc, char** argv){
	if (argc < 9) {
		printf("Wrong parameters\n");
		printf("Example input: my_prog -n 3 -stop 100 -min 4 -max 5.\n");
		exit(0);
	}

	int i;
	for(i=1; i<8; i+=2){
		char* option = argv[i];
		if(strcmp(option, "-n")==0){
			n = atoi(argv[i+1]);
		}
		if(strcmp(option, "-stop")==0){
			stop = atoi(argv[i+1]);
		}
		if(strcmp(option, "-min")==0){
			min = atoi(argv[i+1]);
		}
		if(strcmp(option, "-max")==0){
			max = atoi(argv[i+1]);
		}
	}
	if (n == 0 || stop == 0 || min==0 || max==0) {
		printf("Wrong parameters\n");
		printf("Example input: my_prog -n 3 -stop 100 -min 4 -max 5.\n");
		exit(0);
	}
}


int main(int argc, char** argv)
{
	get_parameters(argc, argv);

	stu_lock = (pthread_mutex_t*)malloc(sizeof(pthread_mutex_t)*n);
	stu_waiting = (int*)malloc(sizeof(int)*n);

  //random seed
  srand(time(NULL));

	int i;
	q = (Queue_t*)malloc(sizeof(Queue_t)); // the waiting queue
	initialize(q);

	init_locks();

  //create TA.
  pthread_t tathread;
  pthread_create(&tathread, NULL, ta, NULL);

	//create n students.
	pthread_t* students = (pthread_t*)malloc(sizeof(pthread_t)*n);
	for(i=0; i<n; i++) {
		stu_waiting[i] = 1;
		pthread_create(&students[i], NULL, stu, NULL);
	}

	//mimic operating system's event loop
	while (current_time < stop)
	{
		//do something
		//printf("current time is:%d \n", current_time);
		sleep(1);
		current_time += 1;
	}

	//waiting for children threads
	for(i=0; i<n; i++) {
		pthread_join(students[i], NULL);
	}
	pthread_join(tathread, NULL);

	destroy_locks();

	free(q);
	free(stu_lock);
	free(stu_waiting);
	free(students);

	return(0);
}

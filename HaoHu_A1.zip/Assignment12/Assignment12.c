#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>
#include "Queue.h"


int main(int argc, char** argv)
{
	if (argc < 2) {
		printf("please give a CPU number.\r\n");
		exit(0);
	}

	int n = atoi(argv[1]);
	if (n == 0) {
		printf("please give a valid CPU number.\r\n");
		exit(0);
	}

	char* line;
	FILE *f, *f_out;
	char buff[255];
	f = fopen("input", "r");
	if (!f) {
		printf("failed to open file 'input', please try again.\r\n");
		exit(0);
	}
	f_out = fopen("output", "w");
	if (!f_out) {
		printf("failed to create file 'output', please try again.\r\n");
		exit(0);
	}

	Queue_t* q = (Queue_t*)malloc(sizeof(Queue_t));
	initialize(q);

	int q_size = 0;

	//The first line of input is ignored as the header
	fgets(buff, sizeof(buff), f);

	while(fgets(buff, sizeof(buff), f)) {
		line = buff;
		char* user = (char*)malloc(255);
		char* process = (char*)malloc(255);
		int arrival;
		int duration;
		int r = sscanf(line, "%s\t%s\t%d\t%d", user, process, &arrival, &duration);
		if (r == EOF || r == 0) {
			free(user);
			free(process);
			break;
		} else {
			Job_t job;
			job.user = user;
			job.process = process;
			job.arrival = arrival;
			job.duration = duration;
			enqueue(q, job);
			q_size += 1;
		}
	}

	fclose(f);

	int current_time;
	Job_t waiting_job;
	Job_t* cpu_jobs = (Job_t*)malloc(sizeof(Job_t)*n);
	int* cpu_state = (int*)malloc(sizeof(int)*n);
	int* cpu_idle = (int*)malloc(sizeof(int)*n);

	Summary_t* sums = (Summary_t*)malloc(sizeof(Summary_t)*q_size);
	int user_count = 0;
	int i;
	for (i = 0; i < n; i++) {
		cpu_state[i] = 0; // 0 for idle, 1 for busy
		cpu_idle[i] = 0;
	}

	fprintf(f_out, "Time\tJob\r\n");

	waiting_job = peep(q);
	current_time = waiting_job.arrival;
	int dequeued_count = 0;
	int processed_count = 0;
	//mimic operating system's event loop
	while (1)
	{
		if (processed_count == q_size) {
			break;
		}

		//check if there is idle CPU and waiting job
		for (i = 0; i < n; i++) {
			if (cpu_state[i] == 0) { //CPU is idle
				if (dequeued_count < q_size) { //assign current job to the idle CPU
					Job_t tmp_job = peep(q);
					if (tmp_job.arrival <= current_time) {
						waiting_job = dequeue(q);
						dequeued_count += 1;
						cpu_jobs[i] = waiting_job;
						cpu_state[i] = 1;
						fprintf(f_out, "%d\t%s\r\n", current_time, waiting_job.process);

						//update sums table.
						//check if user exists
						int user_exists = 0;
						int j;
						for (j = 0; j<user_count; j++) {
							if (strcmp(cpu_jobs[i].user, sums[j].user) == 0) {
								sums[j].end = current_time;
								user_exists = 1;
								break;
							}
						}
						if (user_exists == 0) {
							sums[user_count].user = cpu_jobs[i].user;
							sums[user_count].end = current_time + cpu_jobs[i].duration;
							user_count += 1;
						}
						else {
							sums[j].end = current_time + cpu_jobs[i].duration;
						}
					}
				}
				else { //nothing to process now
					if (cpu_idle[i] == 0) {
						if (n == 1) {
							fprintf(f_out, "%d\tIDLE\r\n", current_time);
						}
						else {
							fprintf(f_out, "%d\tCPU%d IDLE\r\n", current_time, i + 1);
						}
						cpu_idle[i] = 1;
					}
				}
			}
			else { //CPU is busy
				if (cpu_jobs[i].duration > 0) {
					cpu_jobs[i].duration -= 1;
				}
				if (cpu_jobs[i].duration == 0) {//a job finished
					cpu_state[i] = 0;
					processed_count += 1;

					if (dequeued_count < q_size) { //assign current job to the idle CPU
						Job_t tmp_job = peep(q);
						if (tmp_job.arrival <= current_time) {
							waiting_job = dequeue(q);
							dequeued_count += 1;
							cpu_jobs[i] = waiting_job;
							cpu_state[i] = 1;
							fprintf(f_out, "%d\t%s\r\n", current_time, waiting_job.process);

							//update sums table.
							//check if user exists
							int user_exists = 0;
							int j;
							for (j = 0; j<user_count; j++) {
								if (strcmp(cpu_jobs[i].user, sums[j].user) == 0) {
									sums[j].end = current_time;
									user_exists = 1;
									break;
								}
							}
							if (user_exists == 0) {
								sums[user_count].user = cpu_jobs[i].user;
								sums[user_count].end = current_time + cpu_jobs[i].duration;
								user_count += 1;
							}
							else {
								sums[j].end = current_time + cpu_jobs[i].duration;
							}
						}
					}
					else { //nothing to process now
						if (cpu_idle[i] == 0) {
							if (n == 1) {
								fprintf(f_out, "%d\tIDLE\r\n", current_time);
							}
							else {
								fprintf(f_out, "%d\tCPU%d IDLE\r\n", current_time, i + 1);
							}
							cpu_idle[i] = 1;
						}
					}
				}
			}
		}

		current_time += 1;
	}

	//print summary finally
	fprintf(f_out, "\r\nSummary\r\n");
	for (i = 0; i < user_count; i++) {
		fprintf(f_out, "%s\t%d\r\n", sums[i].user, sums[i].end);
	}

	fclose(f_out);
	free(cpu_state);
	free(cpu_idle);
	free(cpu_jobs);
	free(sums);
	free(q);

	return(0);
}

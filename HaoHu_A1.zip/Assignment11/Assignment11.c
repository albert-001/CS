#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>
#include "Queue.h"


int main(int argc, char** argv)
{
	char* line;
	FILE *f, *f_out;
	char buff[255];
	f = fopen("input", "r");
	if (!f) {
		printf("failed to open file 'input', please try again.");
		exit(0);
	}
	f_out = fopen("output", "w");
	if (!f_out) {
		printf("failed to create file 'output', please try again.");
		exit(0);
	}

	Queue_t* q = (Queue_t*)malloc(sizeof(Queue_t));
	initialize(q);

	int q_size = 0;

	//The first line of input is ignored as the header
	fgets(buff, sizeof(buff), f);

	while(fgets(buff, sizeof(buff), f)) {
		line = buff;
		char* user = (char*)malloc(255);
		char* process = (char*)malloc(255);
		int arrival;
		int duration;
		int r = sscanf_s(line, "%s\t%s\t%d\t%d", user, 255, process, 255, &arrival, &duration);
		if (r == EOF || r == 0) {
			free(user);
			free(process);
			break;
		} else {
			Job_t job;
			job.user = user;
			job.process = process;
			job.arrival = arrival;
			job.duration = duration;
			enqueue(q, job);
			q_size += 1;
		}
	}

	fclose(f);

	int i;
	Job_t* jobs = (Job_t*)malloc(sizeof(Job_t)*q_size);
	for(i=0; i<q_size; i++) {
		jobs[i] = dequeue(q);
	}

	fprintf(f_out, "Time\tJob\r\n");
	int current_time = jobs[0].arrival;
	int* times = (int*)malloc(sizeof(int)*q_size);
	for (i = 0; i < q_size; i++) {
		times[i] = current_time;
		fprintf(f_out, "%d\t%s\r\n", current_time, jobs[i].process);
		current_time += jobs[i].duration;
	}
	fprintf(f_out, "%d\t%s\r\n", current_time, "IDLE");

	fprintf(f_out, "\r\nSummary\r\n");
	int user_count = 0;
	int user_exits = 0;
	int j;
	Summary_t* sums = (Summary_t*)malloc(sizeof(Summary_t)*q_size);
	for (i = 0; i < q_size; i++) {
		char* user = jobs[i].user;
		for (j = 0; j < user_count; j++) {
			if (strcmp(user, sums[j].user) == 0) {
				user_exits = 1;
				break;
			}
		}
		if (user_exits) {
			sums[j].end = times[i] + jobs[i].duration;
			user_exits = 0;
		}
		else {
			sums[user_count].user = user;
			sums[user_count].end = times[i] + jobs[i].duration;
			user_count += 1;
		}
	}

	for (i = 0; i < user_count; i++) {
		fprintf(f_out, "%s\t%d\r\n", sums[i].user, sums[i].end);
	}

	fclose(f_out);

	free(jobs);
	free(times);
	free(sums);

	return(0);
}
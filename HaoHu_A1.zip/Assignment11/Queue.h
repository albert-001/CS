#ifndef Queue_FILE
#define Queue_FILE

#include <stdio.h>
#include <stdlib.h>
#include "Node.h"


typedef struct Queue {
	QNode_t* head;
	QNode_t* tail;
} Queue_t;

void initialize(Queue_t* q) {
	q->head = NULL;
	q->tail = NULL;
}

void enqueue(Queue_t* q, Job_t job) {
	QNode_t* tmp_node = (QNode_t*)malloc(sizeof(QNode_t));
	tmp_node->job.user = job.user;
	tmp_node->job.process = job.process;
	tmp_node->job.arrival = job.arrival;
	tmp_node->job.duration = job.duration;
	tmp_node->next = NULL;
	if (!q->head) {
		q->head = tmp_node;
		q->tail = tmp_node;
	}
	else {
		q->tail->next = tmp_node;
		q->tail = tmp_node;
	}
}

Job_t dequeue(Queue_t* q) {
	if (!q->head) {
		return NULL;
	}
	else {
		if (q->head == q->tail) {
			QNode_t* tmp_node = q->head;
			q->head = NULL;
			q->tail = NULL;
			Job_t r = tmp_node->job;
			free(tmp_node);
			return r;
		}
		else {
			QNode_t* tmp_node = q->head;
			q->head = q->head->next;
			Job_t r = tmp_node->job;
			free(tmp_node);
			return r;
		}
	}
}

void queue_print(Queue_t* q) {
	QNode_t* tmp_node = q->head;
	while (tmp_node)
	{
		printf("%s ", tmp_node->job.user);
		printf("%s ", tmp_node->job.process);
		printf("%d ", tmp_node->job.arrival);
		printf("%d \r\n", tmp_node->job.duration);
		tmp_node = tmp_node->next;
	}
}

#endif
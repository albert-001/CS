#ifndef LIST_FILE
#define LIST_FILE

#include <stdio.h>
#include <stdlib.h>
#include "Node.h"


typedef struct List {
	QNode_t* head;
	QNode_t* tail;
} List_t;

void list_initialize(List_t* l) {
	l->head = NULL;
	l->tail = NULL;
}

void add(List_t* l, Job_t job) {
	QNode_t* tmp_node = (QNode_t*)malloc(sizeof(QNode_t));
	tmp_node->job.user = job.user;
	tmp_node->job.process = job.process;
	tmp_node->job.arrival = job.arrival;
	tmp_node->job.duration = job.duration;
	tmp_node->next = NULL;
	if (!l->head) {
		l->head = tmp_node;
		l->tail = tmp_node;
	} else {
		if (l->head == l->tail) {
			if ((l->head->job.duration < job.duration) || (l->head->job.duration == job.duration)&&(l->head->job.arrival <= job.arrival)) {
				l->head->next = tmp_node;
				l->tail = tmp_node;
			}
			else {
				tmp_node->next = l->head;
				l->head = tmp_node;
			}
			return;
		}
		QNode_t* p = l->head;
		while (p!=l->tail) {
			if ((p->job.duration < job.duration) || (p->job.duration == job.duration)&&(p->job.arrival <= job.arrival)) {
				if ((p->next->job.duration > job.duration) || (p->next->job.duration == job.duration)&&(p->next->job.arrival > job.arrival)) {
					tmp_node->next = p->next;
					p->next = tmp_node;
					return;
				}
				else {
					p = p->next;
				}
			} else {
				l->head = tmp_node;
				tmp_node->next = p;
				return;
			}
		}
		if (p == l->tail) {
			p->next = tmp_node;
			l->tail = tmp_node;
		}
	}
}

Job_t remove_first(List_t* l) {
	if (!l->head) {
		printf("null list");
		return;
	} else {
		if (l->head == l->tail) {
			QNode_t* tmp_node = l->head;
			l->head = NULL;
			l->tail = NULL;
			Job_t r = tmp_node->job;
			free(tmp_node);
			return r;
		}
		else {
			QNode_t* tmp_node = l->head;
			l->head = l->head->next;
			Job_t r = tmp_node->job;
			free(tmp_node);
			return r;
		}
	}
}

void list_print(List_t* l) {
	QNode_t* tmp_node = l->head;
	while(tmp_node)
	{
		printf("%s\t", tmp_node->job.user);
		printf("%s\t", tmp_node->job.process);
		printf("%d\t", tmp_node->job.arrival);
		printf("%d\t", tmp_node->job.duration);
		tmp_node = tmp_node->next;
	}
	printf("\n");
}

#endif
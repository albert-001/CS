#ifndef Node_FILE
#define Node_FILE

typedef struct QNode
{
	int value;
	struct QNode* next;
} QNode_t;

#endif

#ifndef Node_FILE
#define Node_FILE

typedef struct Job
{
	char* user;
	char* process;
	int arrival;
	int duration;
	int priority;
} Job_t;

typedef struct Summary
{
	char* user;
	int end;
} Summary_t;

typedef struct QNode
{
	struct Job job;
	struct QNode* next;
} QNode_t;

#endif

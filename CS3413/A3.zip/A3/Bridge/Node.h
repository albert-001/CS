#ifndef Node_FILE
#define Node_FILE

typedef struct Car
{
	char* driver;
	char* direction;
	int arrival;
} Car_t;

typedef struct QNode
{
	struct Car car;
	struct QNode* next;
} QNode_t;

#endif

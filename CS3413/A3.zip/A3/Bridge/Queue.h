#ifndef Queue_FILE
#define Queue_FILE

#include <stdio.h>
#include <stdlib.h>
#include "Node.h"


typedef struct Queue {
	QNode_t* head;
	QNode_t* tail;
} Queue_t;

void initialize(Queue_t* q) {
	q->head = NULL;
	q->tail = NULL;
}

Car_t peep(Queue_t* q) {
	if (q->head) {
		return q->head->car;
	}
}

void enqueue(Queue_t* q, Car_t car) {
	QNode_t* tmp_node = (QNode_t*)malloc(sizeof(QNode_t));
	tmp_node->car.driver = car.driver;
	tmp_node->car.direction = car.direction;
	tmp_node->car.arrival = car.arrival;
	tmp_node->next = NULL;
	if (!q->head) {
		q->head = tmp_node;
		q->tail = tmp_node;
	}
	else {
		q->tail->next = tmp_node;
		q->tail = tmp_node;
	}
}

void dequeue(Queue_t* q) {
	if (!q->head) {
		return;
	}
	else {
		if (q->head == q->tail) {
			QNode_t* tmp_node = q->head;
			q->head = NULL;
			q->tail = NULL;
			free(tmp_node);
		}
		else {
			QNode_t* tmp_node = q->head;
			q->head = q->head->next;
			free(tmp_node);
		}
	}
}

void queue_print(Queue_t* q) {
	QNode_t* tmp_node = q->head;
	while (tmp_node)
	{
		printf("%s\t", tmp_node->car.driver);
		printf("%s\t", tmp_node->car.direction);
		printf("%d\n", tmp_node->car.arrival);
		tmp_node = tmp_node->next;
	}
	printf("\n");
}

void queue_sort(Queue_t* q) {
    QNode_t* h1;
    QNode_t* h2;
    QNode_t* h3;
    QNode_t* h = (QNode_t*)malloc(sizeof(QNode_t));
    h->next = q->head;
    for(h3=h->next,h2=h3->next;h2!=NULL;) {
        for(h1=h;h1!=h2;h1=h1->next) {
            if(h1->next->car.arrival > h2->car.arrival) {
               h3->next=h2->next;
               h2->next=h1->next;
               h1->next=h2;
               h2=h3->next;
               break;
            }
        }
 
        if(h1==h2) {
            h2=h2->next;
            h3=h3->next;
        }
    }
    q->head = h->next;
    q->tail = h3;
    free(h);
}


#endif
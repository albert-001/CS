#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <string.h>
#include <semaphore.h>


int n = 5; //number of customers
int wait_count = 0;
int chairs_num = 3; //number of chairs

sem_t cus;
sem_t bab;
sem_t finish;
pthread_mutex_t lock; //access lock

void init_locks(){
	pthread_mutex_init(&lock, NULL);
	sem_init(&cus, 0, 0);
	sem_init(&bab, 0, 0);
	sem_init(&finish, 0, 0);
}

void destroy_locks(){
	pthread_mutex_destroy(&lock);
	sem_destroy(&cus);
	sem_destroy(&bab);
	sem_destroy(&finish);
}

float get_random_time(min, max) { //get random numbers in [min,max]
	float r = ((float)rand()/(float)RAND_MAX)*(max-min) + (float)min;
	return r;
}

void* customers(void* args) {
    int id = *(int*)args;
	pthread_mutex_lock(&lock);
	if(wait_count < chairs_num){
		wait_count += 1;
		sem_post(&cus); // wake up the baber
		pthread_mutex_unlock(&lock);
		printf("customer %d is waiting.\n", id);
		sem_wait(&bab);
		printf("customer %d is cutting hair.\n", id);
		sem_wait(&finish);
		printf("customer %d finished.\n", id);
	}else{ //else leaves
		pthread_mutex_unlock(&lock);
		printf("no seat. customer %d leaves.\n", id);
	}
}

void* baber(void* args) {
	while(1){
		sem_wait(&cus);//wait for customer
		printf("baber brings a customer in.\n");
		pthread_mutex_lock(&lock);
		wait_count -= 1;
		sem_post(&bab);//bring a customer in
		pthread_mutex_unlock(&lock);
		sleep(get_random_time(2,3)); //cutting some time
		sem_post(&finish);//let customer go
		if(wait_count==0){
			printf("baber finished.\n");
			break;
		}
	}
}


void get_parameters(int argc, char** argv){
	if (argc < 5) {
		printf("Wrong parameters\n");
		printf("Example input: %s -customers 5 -chairs 3.\n", argv[0]);
		exit(0);
	}

	int i;
	for(i=1; i<5; i+=2){
		char* option = argv[i];
		if(strcmp(option, "-customers")==0){
			n = atoi(argv[i+1]);
		}
		if(strcmp(option, "-chairs")==0){
			chairs_num = atoi(argv[i+1]);
		}
	}
	if (n==0 || chairs_num==0) {
		printf("Wrong parameters\n");
		printf("Example input: %s -customers 5 -chairs 3.\n", argv[0]);
		exit(0);
	}
}


int main(int argc, char** argv)
{
	get_parameters(argc, argv);

  	//random seed
  	srand(time(NULL));

	int i;

	init_locks();

    //create baber thread.
    pthread_t baber_t;
    pthread_create(&baber_t, NULL, baber, NULL);

	//create customer threads.
	pthread_t* customer_t = (pthread_t*)malloc(sizeof(pthread_t)*n);
	for(i=0; i<n; i++) {
		int *args = (int*)malloc(sizeof(int));
        *args=i+1;
		pthread_create(&customer_t[i], NULL, customers, args);
		sleep(get_random_time(0,2));//the next customer comes some time later
	}

	pthread_join(baber_t, NULL);
	for(i=0; i<n; i++){
        pthread_join(customer_t[i], NULL);
    }

    destroy_locks();

	return(0);
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>

const int e = 1;
#define bigendian() ((*(char*)&e) == 0)

void fifo(int pages[], int m, int frames[], int n, int offset[], char data[]){
    int page_fault = 0;
    if( m<=n ){
        return;
    }
    int cf_index = 0;
    int i, j;
    int frame_no = 0;
    int logical_addr;
    int phy_addr;
    for (i = 0; i < m; i++)
    {
        logical_addr = (pages[i] << 8) + offset[i];
        for (j = 0; j < n; j++)
        {
            if(pages[i] == frames[j]){break;}
        }
        if(j<n){
            frame_no = j;
        }else{
            frame_no = cf_index;
            frames[cf_index]=pages[i];//swap out
            cf_index = (cf_index+1)%n;
            page_fault += 1;
        }
        phy_addr = (frame_no << 8) + offset[i];
        printf("%x -> %x -> %c \n", logical_addr, phy_addr, data[logical_addr]);
    }
    printf("Page fault = %d, Memory access = %d\n", page_fault, m);
}

void lru(int pages[], int m, int frames[], int n, int offset[], char data[]) {
    int page_fault = 0;
    if (m <= n) {
        return;
    }
    int cf_index = 0;
    int* lru_index = (int*)malloc(sizeof(int)*n);
    int i, j, k;
    int frame_no = 0;
    int logical_addr;
    int phy_addr;
    for (k = 0; k < m; k++) {
        logical_addr = (pages[k] << 8) + offset[k];
        for (j = 0; j < n; j++)
        {
            if (pages[k] == frames[j]) { break; }
        }
        if (j < n) {
            frame_no = j;
        }
        else {
            for (j = 0; j < n; j++)
            {
                for (i = k - 1; i >= 0; i--) {
                    if (pages[i] == frames[j]) {
                        lru_index[j] = i;
                        break;
                    }
                }
            }
            int lru_page_i = k;
            for (i = 0; i < n; i++)
            {
                if (lru_index[i] < lru_page_i) {
                    lru_page_i = lru_index[i];
                }
            }
            for (i = 0; i < n; i++) {
                if (lru_page_i == lru_index[i]) {
                    frame_no = i;
                    frames[i] = pages[k];
                    page_fault += 1;
                    break;
                }
            }
        }
        phy_addr = (frame_no << 8) + offset[i];
        printf("%x -> %x -> %c \n", logical_addr, phy_addr, data[logical_addr]);
    }
    free(lru_index);

    printf("Page fault = %d, Memory access = %d\n", page_fault, m);
}

void optimal(int pages[], int m, int frames[], int n, int offset[], char data[]) {
    int page_fault = 0;
    if (m <= n) {
        return;
    }
    int cf_index = 0;
    int* o_index = (int*)malloc(sizeof(int)*n);
    int x;
    int i, j, k;
    int frame_no = 0;
    int logical_addr;
    int phy_addr;
    for (k = 0; k < m; k++) {
        logical_addr = (pages[k] << 8) + offset[k];
        for (x = 0; x < n; x++)
        {
            o_index[x] = m;
        }
        for (j = 0; j < n; j++)
        {
            if (pages[k] == frames[j]) { break; }
        }
        if (j < n) {
            frame_no = j;
        }
        else {      
            for (j = 0; j < n; j++)
            {
                for (i = k; i < m; i++) {
                    if (pages[i] == frames[j]) {
                        o_index[j] = i;
                        break;
                    }
                }
            }           
            int o_page_i = n;
            for (i = 0; i < n; i++)
            {
                if ((o_index[i] != m) && (o_index[i] > o_page_i)) {
                    o_page_i = o_index[i];
                }
            }
            int gotit = -1;
            for (i = 0; i < n; i++)
            {
                if (o_index[i] == m) {
                    gotit = i;
                    break;
                }
            }
            if (gotit!=-1) {
                frames[gotit] = pages[k];
                frame_no = gotit;
                page_fault += 1;
            }
            else {
                for (i = 0; i < n; i++) {
                    if (pages[o_page_i] == frames[i]) {
                        frame_no = i;
                        frames[i] = pages[k];
                        page_fault += 1;
                        break;
                    }
                }
            }
        }
        phy_addr = (frame_no << 8) + offset[i];
        printf("%x -> %x -> %c \n", logical_addr, phy_addr, data[logical_addr]);
    }
    free(o_index);

    printf("Page fault = %d, Memory access = %d\n", page_fault, m);
}


/* ./a.out 10 mem.txt sample_logical_addr.txt*/
int main (int argc, char *argv[])
{
    int n; //number of available frames
    int* frames;
    unsigned short* logical_addrs;
    int* pages;
    int* offsets;
    int input_addr_count = 0;

    int i;
    int n_addr_space = 65536;
    int f_addr_space;
    FILE* f_addr_logical;
    char* addr_space;

    if(argc!=4){
        printf("usage: %s 10 mem.txt sample_logical_addr.txt\n", argv[0]);
        return 1;
    }

	n = atoi(argv[1]);
    if(n==0){
        printf("usage: %s 10 mem.txt sample_logical_addr.txt\n", argv[0]);
        return 1;  
    }

    f_addr_space = open(argv[2], O_RDONLY);
    f_addr_logical = fopen(argv[3], "r");
    if(f_addr_space==-1 || f_addr_logical==NULL){
        printf("failed to open file\n");
        return 1;
    }

    addr_space = mmap(NULL, n_addr_space, PROT_READ, MAP_PRIVATE, f_addr_space, 0);
    if(addr_space == MAP_FAILED){
        printf("failed to mmap file\n");
        return 1;
    }

    frames = (int*)malloc(sizeof(int)*n);

    ssize_t read;
    char* line = NULL;
    size_t len = 0;
    unsigned short phy_addr;
    unsigned short logical_addr;
    unsigned char page_no;
    unsigned char offset;
    while((read = getline(&line, &len, f_addr_logical)) != -1){
        int i = atoi(line);
        if(i==0){continue;}
        input_addr_count+=1;
    }
    logical_addrs = (unsigned short*)malloc(sizeof(unsigned short)*input_addr_count);
    pages = (int*)malloc(sizeof(int)*input_addr_count);
    offsets = (int*)malloc(sizeof(int)*input_addr_count);
    fseek(f_addr_logical, 0, SEEK_SET);
    int addr_count = 0;
    while((read = getline(&line, &len, f_addr_logical)) != -1){
        int i = atoi(line);
        if(i==0){continue;}
        logical_addrs[addr_count++] = (unsigned short)i;
    }
    for(i=0;i<input_addr_count;i++){
        unsigned short la = logical_addrs[i];        
        unsigned char* pla = (char*)&la;
        unsigned char p = pla[1];//little endian
        unsigned char o = pla[0];//little endian
        if(bigendian())
        {
            p = pla[0];//big endian
            o = pla[1];//big endian
        }
        pages[i] = p;
        offsets[i] = o;
    }
    
    for (i = 0; i < n; ++i)
    {
        frames[i] = -1;
    }
    if(n < input_addr_count){
        fifo(pages, input_addr_count, frames, n, offsets, addr_space);
    }else{
        int page_fault = 0;
        int frame_no = 0;
        int logical_addr;
        int phy_addr;
        int cf_index = 0;
        int j,k;
        for (j = 0; j < input_addr_count; ++j)
        {
            for (k = 0; k < input_addr_count; ++k)
            {
                if(frames[k]==pages[j]){break;}
            }
            if(k==input_addr_count){
                frames[cf_index++]=pages[j];
                page_fault+=1;
            }
            logical_addr = (pages[j] << 8) + offsets[j];
            phy_addr = (j << 8) + offsets[j];
            printf("%x -> %x -> %c \n", logical_addr, phy_addr, addr_space[logical_addr]);
        }
        printf("Page fault = %d, Memory access = %d\n", page_fault, input_addr_count);
    }


    free(line);
    free(frames);
    free(logical_addrs);
    free(pages);
    free(offsets);
    munmap(addr_space, n_addr_space);
    close(f_addr_space);
    fclose(f_addr_logical);
    return 0;
}
#include <stdio.h>
#include <stdlib.h>

void bubble_sort(int a[], int n)
{
   int i, j;
   for (i = 0; i < n-1; i++) 
       for (j = 0; j < n-i-1; j++) 
           if (a[j] > a[j+1]){
               a[j] ^= a[j+1];
               a[j+1] ^= a[j];
               a[j] ^= a[j+1];
           }
}

/* ./a.out F 1000 < cylinder_requests.txt*/
int main(int argc, char *argv[])
{
    int n=0; //number cylinders
    int cylinders[10];
    long total=0;
    int i, j;

    if(argc!=3){
        printf("usage: %s F 1000 < cylinder_requests.txt\n", argv[0]);
        return 1;
    }

    char algorithm = argv[1][0];
    int current_pos = atoi(argv[2]);

    int current_direct = 0; //0:going to 0, 1:going to 9999
    if(algorithm =='S' || algorithm =='C' || algorithm =='L'){
        printf("heading towards 0\n");
    }

    char buff[20];
    while(fgets(buff, sizeof(buff), stdin)){
        int min_distance = 10000;
        int min_index = 10;
        int cylinder_no = atoi(buff);
        if (n < 10)
        {
            cylinders[n] = cylinder_no;
        }
        n++;

        if(algorithm =='F'){
            total += abs(current_pos-cylinder_no);
            current_pos = cylinder_no;
        }else if(algorithm =='T'){
            if (n>10)
            {
                bubble_sort(cylinders, 10);
                int next_index = 0;
                for (i = 0; i < 10; ++i)
                {
                    if (cylinders[i] > current_pos)
                    {
                        break;
                    }
                }
                if (i>0)
                {
                    int d1 = abs(current_pos-cylinders[i-1]);
                    int d2 = abs(current_pos-cylinders[i]);
                    if (d1>d2)
                    {
                        next_index = i;
                    }
                    else{
                        next_index = i-1;
                    }
                }
                total += abs(current_pos-cylinders[next_index]);
                current_pos = cylinders[next_index];
                cylinders[next_index] = cylinder_no;
            }
        }else if(algorithm =='S'){
            if (n>10)
            {
                bubble_sort(cylinders, 10);
                if (current_direct==0){
                    if (current_pos < cylinders[0])
                    {
                        total += current_pos; //go to cylinder zero
                        current_pos = 0;
                        current_direct = 1; //come back
                    } else {
                        for (i = 0; i < 10; ++i)
                        {
                            if (cylinders[i] > current_pos)
                            {
                                break;
                            }
                        }
                        total += abs(current_pos-cylinders[i-1]);
                        current_pos = cylinders[i-1];
                        cylinders[i-1] = cylinder_no;
                    }
                } else {
                    if (current_pos > cylinders[9]){
                        total += (9999-current_pos); //go to cylinder zero
                        current_pos = 9999;
                        current_direct = 0; //come back
                    } else {
                        for (i = 0; i < 10; ++i)
                        {
                            if (cylinders[i] > current_pos)
                            {
                                break;
                            }
                        }
                        total += abs(cylinders[i]-current_pos);
                        current_pos = cylinders[i];
                        cylinders[i] = cylinder_no;
                    }
                }
            }
        }else if(algorithm =='C'){
            if (n>10)
            {
                bubble_sort(cylinders, 10);
                if (current_pos < cylinders[0])
                {
                    total += current_pos; //go to cylinder zero
                    total += 1;
                    current_pos = 9999; //go to 9999
                } else {
                    for (i = 0; i < 10; ++i)
                    {
                        if (cylinders[i] > current_pos)
                        {
                            break;
                        }
                    }
                    total += abs(current_pos-cylinders[i-1]);
                    current_pos = cylinders[i-1];
                    cylinders[i-1] = cylinder_no;
                }
            }
        }else if(algorithm =='L'){
            if (n>10)
            {
                bubble_sort(cylinders, 10);
                if (current_direct==0){
                    if (current_pos < cylinders[0])
                    {
                        current_direct = 1; //come back
                        total += abs(cylinders[0]-current_pos);
                        current_pos = cylinders[0];
                        cylinders[0] = cylinder_no;
                    } else {
                        for (i = 0; i < 10; ++i)
                        {
                            if (cylinders[i] > current_pos)
                            {
                                break;
                            }
                        }
                        total += abs(current_pos-cylinders[i-1]);
                        current_pos = cylinders[i-1];
                        cylinders[i-1] = cylinder_no;
                    }
                } else {
                    if (current_pos > cylinders[9]){
                        current_direct = 0; //come back
                        total += abs(current_pos-cylinders[9]);
                        current_pos = cylinders[9];
                        cylinders[9] = cylinder_no;
                    } else {
                        for (i = 0; i < 10; ++i)
                        {
                            if (cylinders[i] > current_pos)
                            {
                                break;
                            }
                        }
                        total += abs(cylinders[i]-current_pos);
                        current_pos = cylinders[i];
                        cylinders[i] = cylinder_no;
                    }
                }
            }
        }
    }

    if (n>10)
    {
        n=10;
    }

    if(algorithm == 'T')
    {
        for(i = 0; i < n; ++i){
            bubble_sort(cylinders, n);
            int next_index = i;
            for (j = i; j < n; ++j)
            {
                if (cylinders[j] > current_pos)
                {
                    break;
                }
            }
            if (j > i)
            {
                int d1 = abs(current_pos-cylinders[j-1]);
                int d2 = abs(current_pos-cylinders[j]);
                if (d1>d2)
                {
                    next_index = j;
                }
                else{
                    next_index = j-1;
                }
            }
            total += abs(current_pos-cylinders[next_index]);
            current_pos = cylinders[next_index];
            cylinders[next_index] = -1;
        }
    }else if(algorithm == 'S'){
        bubble_sort(cylinders, n);
        if (current_direct==0){
            if (current_pos < cylinders[0])
            {
                total += current_pos; //go to cylinder zero
                current_pos = 0;
                for (i = 0; i < n; ++i)
                {
                    total += abs(cylinders[i]-current_pos); //sweep all
                    current_pos = cylinders[i];
                }
            } else if (current_pos >= cylinders[n-1]){
                for (i = n-1; i >= 0; --i)
                {
                    total += abs(current_pos-cylinders[i]); //sweep all
                    current_pos = cylinders[i];
                }
            } else {
                for (i = 0; i < n; ++i)
                {
                    if (cylinders[i] > current_pos)
                    {
                        break;
                    }
                }
                for (j = i-1; j >=0; --j)
                {
                    total += abs(current_pos-cylinders[j]); //sweep all
                    current_pos = cylinders[j];
                }
                total += current_pos;
                current_pos = 0;
                for (j = i; j <n; ++j)
                {
                    total += abs(cylinders[j]-current_pos); //sweep all
                    current_pos = cylinders[j];
                }
            }
        } else {
            if (current_pos <= cylinders[0])
            {
                for (i = 0; i < n; ++i)
                {
                    total += abs(cylinders[i]-current_pos); //sweep all
                    current_pos = cylinders[i];
                }
            } else if (current_pos > cylinders[n-1]){
                total += (9999-current_pos); //go to cylinder 9999
                current_pos = 9999;
                for (i = n-1; i >= 0; --i)
                {
                    total += abs(current_pos-cylinders[i]); //sweep all
                    current_pos = cylinders[i];
                }
            } else {
                for (i = 0; i < n; ++i)
                {
                    if (cylinders[i] > current_pos)
                    {
                        break;
                    }
                }
                for (j = i; j <n; ++j)
                {
                    total += abs(cylinders[j]-current_pos); //sweep all
                    current_pos = cylinders[j];
                }
                total += (9999-current_pos);
                current_pos = 9999;
                for (j = i-1; j >=0; --j)
                {
                    total += abs(current_pos-cylinders[j]); //sweep all
                    current_pos = cylinders[j];
                }
            }
        }
    }else if(algorithm == 'C'){
        bubble_sort(cylinders, n);
        if (current_pos < cylinders[0])
        {
            total += current_pos; //go to cylinder zero
            total += 1;
            current_pos = 9999; //go to 9999
            for (i = n-1; i >= 0; --i)
            {
                total += abs(current_pos-cylinders[i]); //sweep all
                current_pos = cylinders[i];
            }
        } else if(current_pos >= cylinders[n-1]){
            for (j = n-1; j >= 0; --j)
            {
                total += abs(current_pos-cylinders[j]); //sweep all
                current_pos = cylinders[j];
            }
        } else {
            for (i = 0; i < n; ++i)
            {
                if (cylinders[i] > current_pos)
                {
                    break;
                }
            }
            for (j = i-1; j >= 0; --j)
            {
                total += abs(current_pos-cylinders[j]); //sweep all
                current_pos = cylinders[j];
            }
            total += current_pos;
            total += 1;
            current_pos = 9999;
            for (j = n-1; j >= i; --j)
            {
                total += abs(current_pos-cylinders[j]); //sweep all
                current_pos = cylinders[j];
            }
        }
    }else if (algorithm == 'L'){
        bubble_sort(cylinders, n);
        if (current_direct==0){
            if (current_pos < cylinders[0])
            {
                for (i = 0; i < n; ++i)
                {
                    total += abs(cylinders[i]-current_pos); //sweep all
                    current_pos = cylinders[i];
                }
            } else if (current_pos >= cylinders[n-1]){
                for (i = n-1; i >= 0; --i)
                {
                    total += abs(current_pos-cylinders[i]); //sweep all
                    current_pos = cylinders[i];
                }
            } else {
                for (i = 0; i < n; ++i)
                {
                    if (cylinders[i] > current_pos)
                    {
                        break;
                    }
                }
                for (j = i-1; j >=0; --j)
                {
                    total += abs(current_pos-cylinders[j]); //sweep all
                    current_pos = cylinders[j];
                }
                for (j = i; j <n; ++j)
                {
                    total += abs(cylinders[j]-current_pos); //sweep all
                    current_pos = cylinders[j];
                }
            }
        } else {
            if (current_pos < cylinders[0])
            {
                for (i = 0; i < n; ++i)
                {
                    total += abs(cylinders[i]-current_pos); //sweep all
                    current_pos = cylinders[i];
                }
            } else if (current_pos >= cylinders[n-1]){
                for (i = n-1; i >= 0; --i)
                {
                    total += abs(current_pos-cylinders[i]); //sweep all
                    current_pos = cylinders[i];
                }
            } else {
                for (i = 0; i < n; ++i)
                {
                    if (cylinders[i] > current_pos)
                    {
                        break;
                    }
                }
                for (j = i; j <n; ++j)
                {
                    total += abs(cylinders[j]-current_pos); //sweep all
                    current_pos = cylinders[j];
                }
                for (j = i-1; j >=0; --j)
                {
                    total += abs(current_pos-cylinders[j]); //sweep all
                    current_pos = cylinders[j];
                }
            }
        }        
    }

    printf("total number of disk head movements %ld\n", total);

    return 0;
}
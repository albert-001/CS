#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/mman.h>


const int e = 1;
#define bigendian() ((*(char*)&e) == 0)

char* dirt;

void fifo(int pages[], int m, int frames[], int n, int offset[], char data[]){
    int dirty_pages = 0;
    int page_fault = 0;
    if( m<=n ){
        return;
    }
    int cf_index = 0;
    int i, j;
    int frame_no = 0;
    unsigned short logical_addr;
    int phy_addr;
    for(i = 0; i < m; i++)
    {
        logical_addr = (pages[i] << 8) + offset[i];
        for(j = 0; j < n; j++)
        {
            if(pages[i] == frames[j]){break;}
        }
        if(j<n){
            frame_no = j;
        }else{
            frame_no = cf_index;
            if(dirt[pages[i]]){
                dirty_pages++;
                dirt[pages[i]] = 0;
            }
            frames[cf_index]=pages[i];//swap out
            cf_index = (cf_index+1)%n;
            page_fault += 1;
        }
        phy_addr = (frame_no << 8) + offset[i];
        printf("%x -> %x -> %c \n", logical_addr, phy_addr, data[logical_addr]);
    }
    for(i = 0; i < n; ++i)
    {
        if(dirt[frames[i]])
        {
            dirty_pages++;
        }
    }
    printf("Page fault = %d, Memory access = %d, Dirty pages swapped out = %d\n", page_fault, m, dirty_pages);
}


/* ./a.out 10 mem.txt < sample_logical_addr.txt*/
int main(int argc, char *argv[])
{
    int n; //number of available frames
    int* frames;
    unsigned short* logical_addrs;
    int* pages;
    int* offsets;
    int input_addr_count = 0;

    int i;
    int n_addr_space = 65536;
    int f_addr_space;
    char* addr_space = (char*)malloc(n_addr_space);

    if(argc!=3){
        printf("usage: %s 10 mem.txt < sample_logical_addr.txt\n", argv[0]);
        return 1;
    }

	n = atoi(argv[1]);
    if(n==0){
        printf("usage: %s 10 mem.txt < sample_logical_addr.txt\n", argv[0]);
        return 1;  
    }

    f_addr_space = open(argv[2], O_RDONLY);

    char* p = mmap(NULL, n_addr_space, PROT_READ, MAP_PRIVATE, f_addr_space, 0);
    if(p == MAP_FAILED){
        printf("failed to mmap file\n");
        close(f_addr_space);
        return 1;
    }
    memcpy(addr_space, p, n_addr_space);
    munmap(p, n_addr_space);
    close(f_addr_space);

    frames = (int*)malloc(sizeof(int)*n);

    char buff[20];
    logical_addrs = (unsigned short*)malloc(sizeof(unsigned short)*1000);
    dirt = (char*)malloc(1000);
    memset(dirt, 0, 1000);
    pages = (int*)malloc(sizeof(int)*1000);
    offsets = (int*)malloc(sizeof(int)*1000);

    while(fgets(buff, sizeof(buff), stdin)){
        char i = buff[0];
        unsigned short add;
        char c;

        if(i=='R')
        {
            sscanf(buff, "R %hu", &add);
            logical_addrs[input_addr_count] = add;       
            unsigned char* pla = (char*)&add;
            unsigned char p = pla[1];//little endian
            unsigned char o = pla[0];//little endian
            if(bigendian())
            {
                p = pla[0];//big endian
                o = pla[1];//big endian
            }
            pages[input_addr_count] = p;
            offsets[input_addr_count] = o;
            input_addr_count++;
        }else if(i=='W'){
            sscanf(buff, "W %hu %c", &add, &c);
            logical_addrs[input_addr_count] = add;
            addr_space[add] = c;
            unsigned char* pla = (char*)&add;
            unsigned char p = pla[1];//little endian
            unsigned char o = pla[0];//little endian
            if(bigendian())
            {
                p = pla[0];//big endian
                o = pla[1];//big endian
            }
            pages[input_addr_count] = p;
            offsets[input_addr_count] = o;
            input_addr_count++;
            dirt[p] = 1;
        }else{
            break;
        }
    }

    
    for (i = 0; i < n; ++i)
    {
        frames[i] = -1;
    }
    if(n < input_addr_count){
        fifo(pages, input_addr_count, frames, n, offsets, addr_space);
    }else{
        int dirty_pages = 0;
        int page_fault = 0;
        int frame_no = 0;
        int logical_addr;
        int phy_addr;
        int cf_index = 0;
        int j,k;
        for (j = 0; j < input_addr_count; ++j)
        {
            for (k = 0; k < input_addr_count; ++k)
            {
                if(frames[k]==pages[j]){break;}
            }
            if(k==input_addr_count){
                if(dirt[pages[i]]){
                    dirty_pages++;
                    dirt[pages[i]] = 0;
                }
                frames[cf_index++]=pages[j];//swap out
                page_fault+=1;
            }
            logical_addr = (pages[j] << 8) + offsets[j];
            phy_addr = (j << 8) + offsets[j];
            printf("%x -> %x -> %c \n", logical_addr, phy_addr, addr_space[logical_addr]);
        }
        for(i = 0; i < n; ++i)
        {
            if(dirt[frames[i]])
            {
                dirty_pages++;
            }
        }
        printf("Page fault = %d, Memory access = %d, Dirty pages swapped out = %d\n", page_fault, input_addr_count, dirty_pages);
    }

    FILE* fp = fopen(argv[2], "w" );
    fwrite(addr_space, 1, n_addr_space, fp);
    fclose(fp);

    free(dirt);
    free(addr_space);
    free(frames);
    free(logical_addrs);
    free(pages);
    free(offsets);
    return 0;
}